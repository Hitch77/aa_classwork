class Cart < ApplicationRecord
  
end
