class Dish < ApplicationRecord
  
end
